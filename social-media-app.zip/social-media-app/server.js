const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const nodemailer = require('nodemailer');
const { body, validationResult } = require('express-validator');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const http = require('http');
const socketIo = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

const PORT = process.env.PORT || 3000;

// Database setup
const db = new sqlite3.Database('./database.db');

// Initialize database
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    email_verified INTEGER DEFAULT 0
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS friend_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sender_id INTEGER,
    receiver_id INTEGER,
    status TEXT CHECK(status IN ('pending', 'accepted', 'rejected')),
    FOREIGN KEY(sender_id) REFERENCES users(id),
    FOREIGN KEY(receiver_id) REFERENCES users(id)
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS friends (
    user_id INTEGER,
    friend_id INTEGER,
    PRIMARY KEY(user_id, friend_id),
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(friend_id) REFERENCES users(id)
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sender_id INTEGER,
    receiver_id INTEGER,
    content TEXT NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(sender_id) REFERENCES users(id),
    FOREIGN KEY(receiver_id) REFERENCES users(id)
  )`);
});

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
  secret: 'your_secret_key',
  resave: false,
  saveUninitialized: false
}));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware to check if user is authenticated
function isAuthenticated(req, res, next) {
  if (req.session.userId) {
    next();
  } else {
    res.redirect('/login');
  }
}

// Routes

// Home
app.get('/', (req, res) => {
  res.render('index');
});

// Registration
app.get('/register', (req, res) => {
  res.render('register', { errors: [] });
});

app.post('/register', [
  body('name').notEmpty().withMessage('Name is required'),
  body('email').isEmail().withMessage('Enter a valid email'),
  body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters long')
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).render('register', { errors: errors.array() });
  }

  const { name, email, password } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);

  db.run('INSERT INTO users (name, email, password, email_verified) VALUES (?, ?, ?, ?)', [name, email, hashedPassword, 0], function(err) {
    if (err) {
      return res.status(500).render('error', { message: 'Failed to register user' });
    }

    const userId = this.lastID;
    const verificationLink = `http://localhost:${PORT}/verify-email?userId=${userId}`;

    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'shaykhul2004@gmail.com',
        pass: 'ulee sbdr sxws amlc'
      }
    });

    const mailOptions = {
      from: 'shaykhul2004@gmail.com',
      to: email,
      subject: 'Verify your email',
      text: `Click this link to verify your email: ${verificationLink}`
    };

    transporter.sendMail(mailOptions, (err) => {
      if (err) {
        return res.status(500).render('error', { message: 'Failed to send verification email' });
      }
      res.render('verify-email');
    });
  });
});

// Email Verification
app.get('/verify-email', (req, res) => {
  const { userId } = req.query;

  db.run('UPDATE users SET email_verified = ? WHERE id = ?', [1, userId], (err) => {
    if (err) {
      return res.status(500).render('error', { message: 'Failed to verify email' });
    }
    res.render('verified');
  });
});

// Login
app.get('/login', (req, res) => {
  res.render('login', { errors: [] });
});

app.post('/login', [
  body('email').isEmail().withMessage('Enter a valid email'),
  body('password').notEmpty().withMessage('Password is required')
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).render('login', { errors: errors.array() });
  }

  const { email, password } = req.body;

  db.get('SELECT * FROM users WHERE email = ?', [email], async (err, user) => {
    if (err || !user) {
      return res.status(401).render('login', { errors: [{ msg: 'Invalid email or password' }] });
    }

    const match = await bcrypt.compare(password, user.password);
    if (!match) {
      return res.status(401).render('login', { errors: [{ msg: 'Invalid email or password' }] });
    }

    if (!user.email_verified) {
      return res.status(403).render('login', { errors: [{ msg: 'Please verify your email before logging in' }] });
    }

    req.session.userId = user.id;
    req.session.username = user.name;
    res.redirect('/dashboard');
  });
});

// Dashboard
app.get('/dashboard', isAuthenticated, (req, res) => {
  const userId = req.session.userId;

  db.serialize(() => {
    db.all('SELECT friend_requests.id, users.name, users.email FROM friend_requests JOIN users ON friend_requests.sender_id = users.id WHERE friend_requests.receiver_id = ? AND friend_requests.status = ?', [userId, 'pending'], (err, requests) => {
      if (err) {
        return res.status(500).render('error', { message: 'Failed to retrieve friend requests' });
      }
      
      db.all('SELECT users.id, users.name, users.email FROM friends JOIN users ON friends.friend_id = users.id WHERE friends.user_id = ?', [userId], (err, friends) => {
        if (err) {
          return res.status(500).render('error', { message: 'Failed to retrieve friends list' });
        }
        
        res.render('dashboard', {
          username: req.session.username,
          userId: userId,
          requests: requests,
          friends: friends,
          searchResults: [] // Initialize search results as empty array
        });
      });
    });
  });
});

// Search for friends
app.get('/search', isAuthenticated, (req, res) => {
  const { query } = req.query;

  if (!query || query.trim() === '') {
    return res.status(400).render('search-results', { users: [], error: 'Search query cannot be empty' });
  }

  db.all('SELECT id, name, email FROM users WHERE name LIKE ? AND id != ?', [`%${query}%`, req.session.userId], (err, users) => {
    if (err) {
      return res.status(500).render('error', { message: 'Failed to search users' });
    }
    res.render('search-results', { users, error: null });
  });
});

/// Send friend request
app.post('/send-friend-request', isAuthenticated, [
  body('receiverId').isInt().withMessage('Invalid user ID')
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).render('error', { message: 'Invalid friend request', errors: errors.array() });
  }

  const { receiverId } = req.body;
  const senderId = req.session.userId;

  db.serialize(() => {
    db.run('BEGIN TRANSACTION');

    db.get('SELECT * FROM users WHERE id = ?', [receiverId], (err, receiver) => {
      if (err) {
        db.run('ROLLBACK');
        return res.status(500).render('error', { message: 'Error checking receiver existence' });
      }
      if (!receiver) {
        db.run('ROLLBACK');
        return res.status(404).render('error', { message: 'Receiver not found' });
      }

      // Check existing friendships
      db.get('SELECT * FROM friends WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)', [senderId, receiverId, receiverId, senderId], (err, existingFriendship) => {
        if (err) {
          db.run('ROLLBACK');
          return res.status(500).render('error', { message: 'Error checking existing friendships' });
        }
        if (existingFriendship) {
          db.run('ROLLBACK');
          return res.status(400).render('error', { message: 'Already friends' });
        }

        // Check existing friend requests
        db.get('SELECT * FROM friend_requests WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)', [senderId, receiverId, receiverId, senderId], (err, existingRequest) => {
          if (err) {
            db.run('ROLLBACK');
            return res.status(500).render('error', { message: 'Error checking existing friend requests' });
          }

          if (existingRequest) {
            if (existingRequest.status === 'pending') {
              db.run('ROLLBACK');
              return res.status(400).render('error', { message: 'Friend request already sent' });
            } else {
              db.run('DELETE FROM friend_requests WHERE id = ?', [existingRequest.id], (err) => {
                if (err) {
                  db.run('ROLLBACK');
                  return res.status(500).render('error', { message: 'Error removing previous friend request' });
                }

                db.run('INSERT INTO friend_requests (sender_id, receiver_id, status) VALUES (?, ?, ?)', [senderId, receiverId, 'pending'], (err) => {
                  if (err) {
                    db.run('ROLLBACK');
                    return res.status(500).render('error', { message: 'Failed to send friend request' });
                  }

                  db.run('COMMIT');
                  res.redirect('/dashboard');
                });
              });
            }
          } else {
            db.run('INSERT INTO friend_requests (sender_id, receiver_id, status) VALUES (?, ?, ?)', [senderId, receiverId, 'pending'], (err) => {
              if (err) {
                db.run('ROLLBACK');
                return res.status(500).render('error', { message: 'Failed to send friend request' });
              }

              db.run('COMMIT');
              res.redirect('/dashboard');
            });
          }
        });
      });
    });
  });
});


// Accept friend request
app.post('/accept-friend-request', isAuthenticated, [
  body('requestId').isInt().withMessage('Invalid request ID')
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).render('error', { message: 'Invalid friend request' });
  }

  const { requestId } = req.body;
  const userId = req.session.userId;

  db.serialize(() => {
    db.get('SELECT * FROM friend_requests WHERE id = ? AND receiver_id = ?', [requestId, userId], (err, request) => {
      if (err || !request) {
        return res.status(400).render('error', { message: 'Invalid friend request' });
      }

      db.run('BEGIN TRANSACTION');

      db.run('UPDATE friend_requests SET status = ? WHERE id = ?', ['accepted', requestId], (err) => {
        if (err) {
          db.run('ROLLBACK');
          return res.status(500).render('error', { message: 'Failed to accept friend request' });
        }

        db.run('INSERT INTO friends (user_id, friend_id) VALUES (?, ?), (?, ?)', [userId, request.sender_id, request.sender_id, userId], (err) => {
          if (err) {
            db.run('ROLLBACK');
            return res.status(500).render('error', { message: 'Failed to add friend' });
          }

          db.run('COMMIT');
          res.redirect('/dashboard');
        });
      });
    });
  });
});
// Decline friend request
app.post('/decline-friend-request', isAuthenticated, [
  body('requestId').isInt().withMessage('Invalid request ID')
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).render('error', { message: 'Invalid friend request' });
  }

  const { requestId } = req.body;
  const userId = req.session.userId;

  db.serialize(() => {
    db.get('SELECT * FROM friend_requests WHERE id = ? AND receiver_id = ?', [requestId, userId], (err, request) => {
      if (err || !request) {
        return res.status(400).render('error', { message: 'Invalid friend request' });
      }

      db.run('UPDATE friend_requests SET status = ? WHERE id = ?', ['rejected', requestId], (err) => {
        if (err) {
          return res.status(500).render('error', { message: 'Failed to decline friend request' });
        }
        res.redirect('/dashboard');
      });
    });
  });
});

/// Remove friend
app.post('/remove-friend', isAuthenticated, [
  body('friendId').isInt().withMessage('Invalid friend ID')
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).render('error', { message: 'Invalid friend ID', errors: errors.array() });
  }

  const { friendId } = req.body;
  const userId = req.session.userId;

  db.serialize(() => {
    db.run('BEGIN TRANSACTION');

    db.get('SELECT * FROM friends WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)', [userId, friendId, friendId, userId], (err, friendship) => {
      if (err) {
        db.run('ROLLBACK');
        return res.status(500).render('error', { message: 'Error retrieving friendship' });
      }
      if (!friendship) {
        db.run('ROLLBACK');
        return res.status(400).render('error', { message: 'Friendship not found' });
      }

      db.run('DELETE FROM friends WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)', [userId, friendId, friendId, userId], (err) => {
        if (err) {
          db.run('ROLLBACK');
          return res.status(500).render('error', { message: 'Failed to remove friend' });
        }

        // Remove any pending friend request from the removed friend
        db.run('DELETE FROM friend_requests WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)', [userId, friendId, friendId, userId], (err) => {
          if (err) {
            db.run('ROLLBACK');
            return res.status(500).render('error', { message: 'Error removing pending friend request' });
          }

          db.run('COMMIT');
          res.redirect('/dashboard');
        });
      });
    });
  });
});
// Chat routes
app.get('/chat/:friendId', isAuthenticated, (req, res) => {
  const { friendId } = req.params;
  const userId = req.session.userId;

  db.serialize(() => {
    // Check if the users are friends
    db.get('SELECT * FROM friends WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)', [userId, friendId, friendId, userId], (err, friendship) => {
      if (err || !friendship) {
        console.error('Friendship check failed:', err);
        return res.status(400).render('error', { message: 'You are not friends with this user' });
      }

      // Fetch chat messages
      db.all('SELECT * FROM messages WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) ORDER BY timestamp ASC', [userId, friendId, friendId, userId], (err, messages) => {
        if (err) {
          console.error('Failed to retrieve chat messages:', err);
          return res.status(500).render('error', { message: 'Failed to retrieve chat messages' });
        }

        // Fetch friend's name
        db.get('SELECT name FROM users WHERE id = ?', [friendId], (err, friend) => {
          if (err) {
            console.error('Failed to fetch friend\'s information:', err);
            return res.status(500).render('error', { message: 'Failed to retrieve friend\'s information' });
          }
          if (!friend) {
            console.error('No user found with the provided friendId:', friendId);
            return res.status(500).render('error', { message: 'Friend\'s information not found' });
          }

          res.render('chat', {
            userId: userId,
            friendId: friendId,
            friendName: friend.name, // Pass friend's name to the template
            messages: messages
          });
        });
      });
    });
  });
});

// Handle WebSocket connections for real-time chat
const handleError = (err, message, socket) => {
  console.error(message, err);
  socket.emit('errorMessage', { message: 'An error occurred. Please try again later.' });
};

// Handle WebSocket connections for real-time chat
io.on('connection', (socket) => {
  console.log('A user connected:', socket.id);

  socket.on('joinRoom', ({ userId, friendId }) => {
    try {
      const roomName = `room_${[userId, friendId].sort().join('_')}`;
      socket.join(roomName);
      console.log(`User ${userId} joined room with ${friendId}`);

      // Retrieve chat history from the database
      db.all('SELECT * FROM messages WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)', 
        [userId, friendId, friendId, userId], 
        (err, rows) => {
          if (err) {
            handleError(err, 'Failed to retrieve chat history', socket);
            return;
          }
          // Emit chat history to the client
          socket.emit('chatHistory', rows);
        });
    } catch (err) {
      handleError(err, 'Failed to join room', socket);
    }
  });

  socket.on('sendMessage', (message) => {
    const { senderId, receiverId, content } = message;
    const roomName = `room_${[senderId, receiverId].sort().join('_')}`;

    db.run('INSERT INTO messages (sender_id, receiver_id, content) VALUES (?, ?, ?)', [senderId, receiverId, content], (err) => {
      if (err) {
        handleError(err, 'Failed to save message', socket);
        return;
      }

      io.to(roomName).emit('receiveMessage', message);
    });
  });

  socket.on('typing', ({ userId, friendId }) => {
    try {
      const roomName = `room_${[userId, friendId].sort().join('_')}`;
      socket.broadcast.to(roomName).emit('userTyping', { userId });
    } catch (err) {
      handleError(err, 'Failed to send typing status', socket);
    }
  });

  socket.on('stopTyping', ({ userId, friendId }) => {
    try {
      const roomName = `room_${[userId, friendId].sort().join('_')}`;
      socket.broadcast.to(roomName).emit('userStoppedTyping', { userId });
    } catch (err) {
      handleError(err, 'Failed to send stop typing status', socket);
    }
  });

  socket.on('disconnect', () => {
    console.log('A user disconnected:', socket.id);
  });
});


// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception thrown:', err);
});


// Logout
app.get('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).render('error', { message: 'Failed to log out' });
    }
    res.redirect('/');
  });
});

// Error handling middleware
app.use((req, res, next) => {
  res.status(404).render('error', { message: 'Page not found' });
});

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).render('error', { message: 'Something went wrong' });
});


// Error handling
app.use((req, res, next) => {
  res.status(404).render('error', { message: 'Page not found' });
});

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).render('error', { message: 'Internal Server Error' });
});

server.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
