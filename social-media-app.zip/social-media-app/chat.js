<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Chat</title>
  <link rel="stylesheet" href="/styles.css">
  <script src="/socket.io/socket.io.js"></script>
  <script>
    document.addEventListener('DOMContentLoaded', () => {
      const socket = io();
      const userId = '<%= userId %>';
      const friendId = '<%= friendId %>';
      const room = [userId, friendId].sort().join('-');

      socket.emit('joinRoom', { userId, friendId });

      const messageForm = document.getElementById('message-form');
      const messageInput = document.getElementById('message-input');
      const messagesContainer = document.getElementById('messages');
      const typingIndicator = document.getElementById('typing-indicator');

      messageForm.addEventListener('submit', (event) => {
        event.preventDefault();
        const content = messageInput.value.trim();
        if (content) {
          socket.emit('sendMessage', { senderId: userId, receiverId: friendId, content });
          messageInput.value = '';
        }
      });

      messageInput.addEventListener('input', () => {
        socket.emit('typing', { userId, friendId });
      });

      socket.on('receiveMessage', (message) => {
        const messageElement = document.createElement('div');
        messageElement.classList.add('message');
        messageElement.textContent = `${message.senderId === userId ? 'You' : 'Friend'}: ${message.content}`;
        messagesContainer.appendChild(messageElement);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
      });

      socket.on('typing', (data) => {
        if (data.userId !== userId) {
          typingIndicator.textContent = 'Friend is typing...';
          setTimeout(() => {
            typingIndicator.textContent = '';
          }, 1000);
        }
      });

      socket.on('errorMessage', (error) => {
        alert(error.message);
      });
    });
  </script>
  <style>
    body {
      font-family: Arial, sans-serif;
      display: flex;
      flex-direction: column;
      align-items: center;
      background-color: #f0f0f0;
    }

    #messages {
      width: 80%;
      max-width: 600px;
      height: 400px;
      border: 1px solid #ccc;
      background-color: #fff;
      overflow-y: scroll;
      padding: 10px;
      margin-bottom: 10px;
    }

    .message {
      padding: 5px;
      border-bottom: 1px solid #eee;
    }

    #message-form {
      width: 80%;
      max-width: 600px;
      display: flex;
    }

    #message-input {
      flex: 1;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 5px 0 0 5px;
      outline: none;
    }

    button {
      padding: 10px;
      border: 1px solid #ccc;
      border-left: 0;
      background-color: #007bff;
      color: #fff;
      border-radius: 0 5px 5px 0;
      cursor: pointer;
    }

    button:hover {
      background-color: #0056b3;
    }

    #typing-indicator {
      font-style: italic;
      color: #888;
    }
  </style>
</head>
<body>
  <h1>Chat with Friend (User ID: <%= userId %>)</h1>
  <div id="messages">
    <% messages.forEach(message => { %>
      <div class="message"><%= message.senderId === userId ? 'You' : 'Friend' %>: <%= message.content %></div>
    <% }) %>
  </div>
  <div id="typing-indicator"></div>
  <form id="message-form">
    <input type="text" id="message-input" placeholder="Type a message" required>
    <button type="submit">Send</button>
  </form>
</body>
</html>
